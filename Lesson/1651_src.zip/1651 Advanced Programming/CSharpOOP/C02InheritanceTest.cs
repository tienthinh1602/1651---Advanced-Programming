﻿using CSharpOOP.c02.inheritance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpOOP
{
    class C02InheritanceTest
    {
		public static void Main(string[] args)
		{
			FootballPlayer demo = new FootballPlayer();
			Console.WriteLine("Player's name: " + demo.Name);
			Console.WriteLine("Player's number: " + demo.Number);
			demo.Pass();
			demo.Shoot();

			Forward john = new Forward("John Cane", 10);
			Console.WriteLine("Player's name: " + john.Name);
			Console.WriteLine("Player's number: " + john.Number);
			john.Pass();
			john.Shoot();
			john.Practice();

			//raise qns about default constructor with demoFwd
			Forward demoFwd = new Forward();
			Console.WriteLine("Forward's name: " + demoFwd.Name);
			Console.WriteLine("Forward's number: " + demoFwd.Number);

            GoalKeeper demoGK = new GoalKeeper();
            Console.WriteLine("GoalKeeper's name: " + demoGK.Name);
            Console.WriteLine("GoalKeeper's number: " + demoGK.Number);

            demoGK = new GoalKeeper("Man", 2);
            Console.WriteLine("GoalKeeper's name: " + demoGK.Name);
            Console.WriteLine("GoalKeeper's number: " + demoGK.Number);
            //try removing super(...)
            //exp constructor of super and sub class

            GoalKeeper bob = new GoalKeeper("Bobby", 0x1);
            bob.CatchBall();
            bob.Practice(); //exp overriding method
            bob.PracticePassing(); // how to make a short pass as a football player???

            Console.Read();

			/// <summary>
			/// In Java, each subclass can have one and only one direct superclass, 
			/// i.e., SINGLE INHERITANCE. 
			/// On the other hand, a superclass can have many subclasses.
			/// </summary>

		}
	}
}
