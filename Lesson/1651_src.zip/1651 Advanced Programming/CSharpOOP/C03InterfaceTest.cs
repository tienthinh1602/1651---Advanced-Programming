﻿using CSharpOOP.c03.interface1;
using System;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace CSharpOOP
{
	/// 
	/// <summary>
	/// @author Administrator
	/// </summary>
	public class TestInterface
	{
		public static void Main(string[] args)
		{
			ICalculator c;

			c = new StringCalculator();
			Console.WriteLine(c.SumDigits(4621684));

			c = new SmartCalculator();
			Console.WriteLine(c.SumDigits(4621684));

			SmartCalculator sc = new SmartCalculator();
			Console.WriteLine(sc.SumDigits(4621684));
			//        sc.doNotCallMe(); //expose class implementation
			//        c.doNotCallMe(); //compile error

			Console.Read();
		}
	}

	//        System.out.println(c.reverseNumber(123456789));

			/// <summary>
			/// As mentioned, Java supports only single inheritance. 
			/// That is, a subclass can be derived from one and only one superclass. 
			/// Java does not support multiple inheritance 
			/// to avoid inheriting conflicting properties from multiple superclasses. 
			/// Multiple inheritance, however, does have its place in programming.
			/// A subclass, however, can implement more than one interfaces. 
			/// This is permitted in Java 
			/// as an interface merely defines the abstract methods 
			/// without the actual implementations 
			/// and less likely leads to inheriting conflicting properties 
			/// from multiple interfaces. 
			/// In other words, Java indirectly supports multiple inheritances 
			/// via implementing multiple interfaces. For example,
			/// 
			/// public class Circle extends Shape implements Movable, Adjustable { 
			/// // extends one superclass but implements multiple interfaces
			/// .......
			/// }
			/// </summary>
}