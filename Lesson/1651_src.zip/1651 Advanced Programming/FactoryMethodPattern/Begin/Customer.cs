﻿using FactoryMethodPattern.Pet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodPattern.Begin
{
    public class Customer
    {
        public string Contact { get; set; }
        public string Name { get; set; }
        public IPet MyPet { get; set; }

        public Customer(string contact, string name)
        {
            Contact = contact;
            Name = name;
        }

        public void SetPet(PetType pt, 
            string name, double weight, int birthYear)
        {
            #region Create A Pet

            if (pt == PetType.DOG)
            {
                var dog = new Dog(name, weight, birthYear);
                dog.IsVaccinated = true;
                MyPet = dog;
            }
            else if(pt == PetType.FISH)
            {
                var fish = new Fish(name, weight);
                fish.Environment = WaterType.FRESH;
                MyPet = fish;
            }

            #endregion
            return;
        }
    }
}
