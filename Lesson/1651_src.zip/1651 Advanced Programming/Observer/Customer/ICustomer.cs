﻿using Observer.Notification;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer.Customer
{
    public interface ICustomer
    {
        int ID { get; set; }
        string Contact { get; set; }
        string Name { get; set; }
        
        void Update(int dataId);

    }
}
