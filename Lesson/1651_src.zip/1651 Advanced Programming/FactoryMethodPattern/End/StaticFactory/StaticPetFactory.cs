﻿using FactoryMethodPattern.Pet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodPattern.End.StaticFactory
{
    public class StaticPetFactory
    {
        public static IPet CreatePet(PetType pt,
            string name, double weight, int birthYear)
        {
            IPet aPet = null;
            #region Create A Pet

            if (pt == PetType.DOG)
            {
                var dog = new Dog(name, weight, birthYear);
                dog.IsVaccinated = true;
                aPet = dog;
            }
            else if (pt == PetType.FISH)
            {
                var fish = new Fish(name, weight);
                fish.Environment = WaterType.FRESH;
                aPet = fish;
            }

            #endregion
            return aPet;
        }
    }
}
