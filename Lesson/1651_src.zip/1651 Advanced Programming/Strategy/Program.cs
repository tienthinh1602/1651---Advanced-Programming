﻿using Strategy.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Begin
            //var order = new Order();
            //var scs = new Begin.ShippingCostService();

            //order.ShipVia = ShippingMethod.AIR;
            //Console.WriteLine("Shipping cost by air: {0}", 
            //    scs.CalculateShippingCost(order));

            //order.ShipVia = ShippingMethod.TRAIN;
            //Console.WriteLine("Shipping cost by train: {0}",
            //    scs.CalculateShippingCost(order));

            //order.ShipVia = ShippingMethod.TRUCK;
            //Console.WriteLine("Shipping cost by truck: {0}",
            //    scs.CalculateShippingCost(order));
            #endregion

            #region End
            var order = new Order();

            var airss = new End.ShippingStrategy.AirShippingStrategy();
            var scs = new End.ShippingCostService(airss);
            Console.WriteLine("Shipping cost by air: {0}",
                scs.CalculateShippingCost(order));

            scs.ShippingStrategy 
                = new End.ShippingStrategy.TrainShippingStrategy();
            Console.WriteLine("Shipping cost by train: {0}",
                scs.CalculateShippingCost(order));

            scs.ShippingStrategy
                = new End.ShippingStrategy.TruckShippingStrategy();
            Console.WriteLine("Shipping cost by truck: {0}",
                scs.CalculateShippingCost(order));

            #endregion

            Console.Read();
        }
    }
}
