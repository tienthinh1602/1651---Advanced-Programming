﻿using Bridge.Services;
using Bridge.ServiceWorker;
using System;

namespace Bridge.Appointment
{
    public class Scheduled : Appointment
    {
        public Scheduled(Service service, IServiceWorker sw)
            : base(service, sw)
        { }

        public override DateTime EstimateCompleteTime()
        {
            double duration = ServiceWorker.TimeTaken(Service);
            var completeTime = ArrivalTime.AddHours(duration);

            if (completeTime.TimeOfDay > new TimeSpan(18, 0, 0))
            {
                //complete time is after 18:00
                //reschedule this appointment to 8am next day
                ArrivalTime = ArrivalTime.AddDays(1).Date
                    + new TimeSpan(8, 0, 0);

                completeTime = ArrivalTime.AddHours(duration);
            }

            return completeTime;
        }
    }
}
