﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy.Model
{
    public enum ShippingMethod
    {
        AIR, TRAIN, TRUCK
    }
}
