﻿/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace CSharpOOP.c02.inheritance
{
	/// 
	/// <summary>
	/// @author Administrator
	/// </summary>
	public class Forward : FootballPlayer
	{

		//should always have default constructor in inheritance
		public Forward()
		{
		}

		public Forward(string name, int number)
		{
			this.Name = name;
			this.Number = number;
		}

	}

}