﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodPattern.Pet
{

    public enum PetType
    {
        DOG, CAT, FISH
    }
    public interface IPet
    {
        string Name { get; set; }
        double Weight { get; set; }
        int BirthYear { get; }
        int GetAge();
    }
}
