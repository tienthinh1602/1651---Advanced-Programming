﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP
{
    public class Square : Rectangle
    {
        public Square()
        {

        }

        public Square(double side) : base(side, side)
        {

        }

        public Square(double side, string color, bool filled)
            : base(side, side, color, filled)
        {

        }

        public double Side
        {
            get => base.Length;
            set
            {
                base.Length = value;
                base.Width = value;
            }
        }

        public override double Length
        {
            get => Side;
            set => Side = value;
        }

        public override double Width
        {
            get => Side;
            set => Side = value;
        }

        public override string ToString()
        {
            return "Square";
        }
    }
}
