﻿using System;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace CSharpOOP.c02.inheritance
{
	/// 
	/// <summary>
	/// @author Administrator
	/// </summary>
	public class FootballPlayer
	{
		private string name;
		private int number;

        //should always have default constructor in inheritance
        public FootballPlayer()
        {
            this.name = "Unknown";
            this.number = 0;
        }

        public FootballPlayer(string name, int number)
		{
			this.name = name;
			this.number = number;
		}

		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				this.name = value;
			}
		}

		public int Number
		{
			get
			{
				return number;
			}
			set
			{
				this.number = value;
			}
		}



		public virtual void Shoot()
		{
			Console.WriteLine("FootballPlayer: shoot()");
		}

		public virtual void Pass()
		{
			Console.WriteLine("FootballPlayer: pass() - a short pass");
		}

		public virtual void Practice()
		{
			Console.WriteLine("FootballPlayer: start practicing***");
			this.Pass();
			this.Shoot();
			Console.WriteLine("FootballPlayer: end practicing***");
		}

	}

}