﻿using Bridge.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge.ServiceWorker
{
    public interface IServiceWorker
    {
        double TimeTaken(Service service);
    }

    public class JuniordWorker : IServiceWorker
    {
        public double TimeTaken(Service service)
        {
            return service.Duration + 0.75;
        }
    }

    public class SeniorWorker : IServiceWorker
    {
        public double TimeTaken(Service service)
        {
            return service.Duration - 0.5;
        }
    }

}
