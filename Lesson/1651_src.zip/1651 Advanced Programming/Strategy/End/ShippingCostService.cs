﻿using Strategy.End.ShippingStrategy;
using Strategy.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy.End
{
    public class ShippingCostService
    {
        public IShippingStrategy ShippingStrategy { private get; set; }

        public ShippingCostService(IShippingStrategy ss)
        {
            ShippingStrategy = ss;
        }

        public double CalculateShippingCost(Order order)
        {
            return ShippingStrategy.CalculateCost(order);
        }
    }
}
