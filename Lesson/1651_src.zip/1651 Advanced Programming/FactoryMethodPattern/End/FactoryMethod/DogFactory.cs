﻿using FactoryMethodPattern.Pet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodPattern.End.FactoryMethod
{
    public class DogFactory : IPetFactory
    {
        public IPet CreatePet(string name, double weight, int birthYear)
        {
            var dog = new Dog(name, weight, birthYear);
            dog.IsVaccinated = true;
            return dog;
        }
    }
}
