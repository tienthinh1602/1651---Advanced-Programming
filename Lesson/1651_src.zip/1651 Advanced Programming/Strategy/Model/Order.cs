﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy.Model
{

    public class Order
    {
        public List<Product> Products { get; set; }

        public ShippingMethod ShipVia { get; set; } 
            = ShippingMethod.TRUCK;

        public Order()
        {
            Products = new List<Product>();
            Products.Add(new Product { 
                Name = "Milk",
                Price = 5.8,
                Weight = 11.2
            });

            Products.Add(new Product
            {
                Name = "Candy",
                Price = 10.12,
                Weight = 8.3
            });

            Products.Add(new Product
            {
                Name = "Biscuit",
                Price = 7.9,
                Weight = 6.3
            });
        }

        public double GetWeight()
        {
            return Products.Sum(p => p.Weight) * 1.05; //5% packaging
        }
    }
}
