﻿using System;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace CSharpOOP.c03.interface1
{
	/// 
	/// <summary>
	/// @author Administrator
	/// </summary>
	public class StringCalculator : ICalculator
	{
		private string NumberToString(int n)
		{
			return Convert.ToString(n);
		}

		public int SumDigits(int n)
		{
			string nStr = NumberToString(n);
			int sum = 0;
			for (int i = 0; i < nStr.Length; i++)
			{
				string digit = nStr.Substring(i, 1);
				sum += int.Parse(digit);
			}
			return sum;
		}

	}

	//    @Override
	//    public int reverseNumber(int n) {
	//        String nStr = numberToString(n);
	//        int length = nStr.length();
	//        String nStrRev = "";
	//        for (int i = length - 1; i >= 0; i--) {
	//            nStrRev += nStr.charAt(i);
	//        }
	//        return Integer.parseInt(nStrRev);
	//    }
}