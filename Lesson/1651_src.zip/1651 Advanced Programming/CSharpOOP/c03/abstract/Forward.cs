﻿using System;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace CSharpOOP.c03.abstract1
{
	/// 
	/// <summary>
	/// @author Administrator
	/// </summary>
	public class Forward : FootballPlayer
	{

		//should always have default constructor in inheritance
		public Forward()
		{
		}

		public Forward(string name, int number)
		{
			this.Name = name;
			this.Number = number;
		}

		public override void Shoot()
		{
			Console.WriteLine("Forward: I'm shooting to score goals.");
		}

		public override void Pass()
		{
			Console.WriteLine("Forward: I'm passing to attack.");
		}



	}

}