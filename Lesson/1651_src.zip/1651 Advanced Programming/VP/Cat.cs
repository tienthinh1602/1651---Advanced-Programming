﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP
{
    public class Cat : IPet
    {
        public string Name { get; set; }

        public Cat() : this(string.Empty)
        {

        }

        public Cat(string name)
        {
            Name = name;
        }

        public void Play()
        {
            Console.WriteLine("Cat is playing");
        }
    }
}
