﻿using FactoryMethodPattern.End.FactoryMethod;
using FactoryMethodPattern.End.StaticFactory;
using FactoryMethodPattern.Pet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            var custName = "Bach";
            var custContact = "+84912345678";
            var petName = "Bap";
            var petBirthYear = 2017;
            var petWeight = 1.2;
            var petType = PetType.DOG;

            #region Static Factory
            var c1 = new Begin.Customer(custName, custContact);
            //c1.SetPet(petType, petName, petWeight, petBirthYear);
            c1.MyPet = StaticPetFactory.CreatePet(petType, petName, petWeight, petBirthYear);
            Console.WriteLine("My pet's age = {0}", c1.MyPet.GetAge());
            #endregion

            #region Factory Method
            var c2 = new End.Customer(custName, custContact);
            
            /*
             * in real projects, we should use .Net Reflection 
             * to dynamically create an appropriate factory instance
             * based on inputs or configurations
             * */
            IPetFactory petFactory = new DogFactory();

            c2.MyPet = petFactory.CreatePet(petName, petWeight, petBirthYear);
            #endregion

            Console.WriteLine("My pet's age = {0}", c2.MyPet.GetAge());

            Console.Read();
        }
    }
}
