﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton
{
    public class Printer
    {
        private int _id;
        
        public int ID { 
            get 
            {
                return _id;
            } 
            private set { _id = value; } 
        }

        public bool PrintDocument(string txt = "")
        {
            if (txt == "" || txt == null)
            {
                Console.WriteLine("Printer_{0} can not print empty document!",
                    this.ID);
                return false;
            }
            else
            {
                Console.WriteLine("Printer_{0} has printed: {1}",
                this.ID, txt);
                return true;
            }
        }

        #region Singleton
        private static Printer _instance = null;

        private Printer()
        {
            ID = new Random().Next(1, 1000);
        }

        public static Printer GetInstance()
        {
            if (_instance == null)
            {
                _instance = new Printer();
            }

            return _instance;
        }
        #endregion
    }
}
