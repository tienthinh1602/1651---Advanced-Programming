﻿using CSharpOOP.c02.polymorphism;
using System;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace CSharpOOP
{
	/// 
	/// <summary>
	/// @author Administrator
	/// </summary>
	public class TestPolymorphism
	{
		public static void Main(string[] args)
		{
			FootballPlayer[] players = new FootballPlayer[3];
			players[0] = new FootballPlayer("John", 12);
			players[1] = new Forward("Kevin", 9);
			players[2] = new GoalKeeper("Bob", 1);

			foreach (FootballPlayer p in players)
			{
				Console.WriteLine(p);
			}

			//demo first then exp variable vs. object
			//finally introduce polymorphism (many forms)
			players[0].Shoot();
			players[1].Shoot();
			players[2].Shoot();

	//        for(FootballPlayer p: players){
	//            p.shoot();
	//        }

	//        players[2].catchBall(); //why can't he catchBall()?
			GoalKeeper gk = (GoalKeeper) players[2]; // correct casting
			gk.CatchBall();

	//        GoalKeeper anotherGK = (GoalKeeper) players[0]; // incorrect casting, runtime error
	//        anotherGK.catchBall();

			//instanceof
			if (players[0] is GoalKeeper)
			{
				GoalKeeper pGK = (GoalKeeper) players[0];
				pGK.CatchBall();
			}
			else
			{
				Console.WriteLine(players[0] + " is not a goal keep, he can't catch ball");
			}

			foreach (FootballPlayer p in players)
			{
				Console.WriteLine(p + " instanceof FootballPlayer: " + (p is FootballPlayer));

				Console.WriteLine(p + " instanceof Forward: " + (p is Forward));

				Console.WriteLine(p + " instanceof GoalKeeper: " + (p is GoalKeeper));
			}

			Console.Read();
		}
	}

}