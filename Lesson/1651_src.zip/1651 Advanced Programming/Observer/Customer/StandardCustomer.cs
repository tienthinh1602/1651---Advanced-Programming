﻿using Observer.Notification;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer.Customer
{
    public class StandardCustomer : ICustomer
    {
        public int ID { get; set; }
        public string Contact { get; set; }
        public string Name { get; set; }
        public NotificationCenter Notifier { get; set; }

        public void Subscribe(NotificationCenter nc)
        {
            nc.Register(this);
            Notifier = nc;
        }
        public void Update(int dataId)
        {
            var data = Notifier.DataSource[dataId];
            Console.WriteLine("StandardCustomer_{0} has received data: {1}",
                ID, data);
        }
    }
}
