﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpOOP.c01
{
    public class Motorbike2
    {
        //instance variable - the attributes
        //it should always be private 
        //what is private? public?
        private string _brand;
        private int _wheels;
        private double _speed = 0.0; //no initialization in constructors
        private double _speedIncrement;

        public string Brand
        {
            get { return _brand; }
            set { _brand = value; }
        }

        public int Wheels
        {
            get { return _wheels; }
            set { _wheels = value; }
        }

        public double SpeedIncrement
        {
            get { return _speedIncrement; }
            set { _speedIncrement = value; }
        }

        public double Speed
        {
            get { return _speed; }
            private set { _speed = value; }
        }

        //constructor
        public Motorbike2()
        {
            this.Brand = "Unknown";
            this.Wheels = 2;
            //this.speed = 0.0d;
            this.SpeedIncrement= 3.0d;
        }
        public Motorbike2(string brand, int wheels, double speedIncrement)
        {
            this.Brand = brand;
            this.Wheels = wheels;
            this.SpeedIncrement = speedIncrement;
            //        this.speed = 0.0d;
        }

        //methods - the actions
        public void Accelerate()
        {
            this.Speed += this.SpeedIncrement;
        }

        public void Stop()
        {
            this.Speed = 0;
        }

        public override string ToString()
        {
            return "Motorbike2: {"
                    + "brand: " + this.Brand + ", "
                    + "speed: " + this.Speed + ", "
                    + "speed_increment: " + this.SpeedIncrement + ", "
                    + "wheels: " + this.Wheels + "}";
        }
    }
}
