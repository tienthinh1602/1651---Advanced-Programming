﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpOOP.c01
{
    class Driver
    {
        //private string _name;

        //public string Name
        //{
        //    get { return _name; }
        //    private set { _name = value; }
        //}

        public string Name { get; private set; }

        public Motorbike2 Bike { get; set; }

        public Driver(string name, Motorbike2 bike)
        {
            this.Name = name;
            this.Bike = bike;
        }

        public void UpgradeBike(double si)
        {
            //        si = Math.min(si, 50);
            if (si > 50)
            {
                si = 50;
            }
            this.Bike.SpeedIncrement = si;
        }

        public void DriveAtSpeed(double minSpeed)
        {
            Motorbike2 myBike = this.Bike;
            while (myBike.Speed < minSpeed)
            {
                myBike.Accelerate();
            }
        }

        public void Stop()
        {
            this.Bike.Stop();
        }

        public void hello()
        {
            return;
        }
    }
}
