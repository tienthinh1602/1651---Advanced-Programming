﻿using System;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace CSharpOOP.c03.abstract1
{
	/// 
	/// <summary>
	/// A class containing one or more abstract methods 
	/// is called an abstract class. 
	/// An abstract class must be declared 
	/// with a class-modifier abstract. 
	/// An abstract class CANNOT be instantiated, 
	/// as its definition is not complete.
	/// </summary>
	public abstract class FootballPlayer
	{
		private string name;
		private int number;

		//should always have default constructor in inheritance
		public FootballPlayer()
		{
			this.name = "Unknown";
			this.number = 0;
		}

		public FootballPlayer(string name, int number)
		{
			this.name = name;
			this.number = number;
		}

		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				this.name = value;
			}
		}

		public int Number
		{
			get
			{
				return number;
			}
			set
			{
				this.number = value;
			}
		}



		/// <summary>
		/// ABSTRACT METHODS of an abstract class
		/// A class containing one or more abstract methods 
		/// is called an abstract class.
		/// </summary>
		public abstract void Shoot();
		public abstract void Pass();
	//    public abstract void tackle();

		public virtual void Practice()
		{
			Console.WriteLine("FootballPlayer: start practicing***");
			this.Pass();
			this.Shoot();
			Console.WriteLine("FootballPlayer: end practicing***");
		}

		public override string ToString()
		{
			return "Name: " + this.Name + ", Number: " + this.Number;
		}


	}

}