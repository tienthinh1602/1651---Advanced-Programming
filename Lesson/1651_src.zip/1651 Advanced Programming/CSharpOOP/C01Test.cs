﻿using CSharpOOP.c01;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpOOP
{
    class C01Test
    {
        static void Main(string[] args)
        {
            Motorbike1 demo = new Motorbike1();
            Console.WriteLine("Demo brand: " + demo.brand);
            Console.WriteLine("Demo wheels: " + demo.wheels);
            Console.WriteLine("Demo speed: " + demo.speed);

            demo.Accelerate();
            Console.WriteLine("Demo speed: " + demo.speed);

            demo.Stop();
            Console.WriteLine("Demo speed: " + demo.speed);
            Console.WriteLine("Demo: " + demo); //so-called ID

            Motorbike1 lead = new Motorbike1("Honda Lead", 2, 10);
            Console.WriteLine("Lead brand: " + lead.brand);
            Console.WriteLine("Lead wheels: " + lead.wheels);
            Console.WriteLine("Lead speed: " + lead.speed);

            lead.Accelerate();
            lead.Accelerate();
            Console.WriteLine("Lead speed: " + lead.speed);

            lead.Stop();
            Console.WriteLine("Lead speed: " + lead.speed);
            Console.WriteLine("Lead: " + lead); //so-called ID

            lead.speed = 45; // this is not OOP
            Console.WriteLine("Lead speed: " + lead.speed);

            Motorbike2 wave = new Motorbike2("Honda Wave", 2, 17);
            Console.WriteLine("Wave brand: " + wave.Brand);
            Console.WriteLine("Wave wheels: " + wave.Wheels);
            Console.WriteLine("Wave speed: " + wave.Speed);

            //wave.Speed = 17;
            wave.Accelerate();
            wave.Accelerate();
            Console.WriteLine("Wave speed: " + wave.Speed);

            wave.Stop();
            wave.Wheels = 3;
            wave.SpeedIncrement = 39;
            wave.Accelerate();
            Console.WriteLine("Wave wheels: " + wave.Wheels);
            Console.WriteLine("Wave speed: " + wave.Speed);

            //toString method
            //if commented: sout memory location
            Console.WriteLine("***************");
            Console.WriteLine(wave);
            Console.WriteLine("***************");

            Motorbike2 airBlade = new Motorbike2("Honda Airblade", 2, 19);
            Driver john = new Driver("John", airBlade);
            john.UpgradeBike(70);
            Console.WriteLine("John's bike's speed increment: " + john.Bike.SpeedIncrement);

            john.DriveAtSpeed(130);
            Console.WriteLine("John is now driving at " + john.Bike.Speed);
            john.Stop();

            //stop console to see output
            Console.Read();
        }
    }
}
