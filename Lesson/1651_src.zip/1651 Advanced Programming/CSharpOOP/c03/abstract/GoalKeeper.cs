﻿using System;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace CSharpOOP.c03.abstract1
{
	/// 
	/// <summary>
	/// @author Administrator
	/// </summary>
	public class GoalKeeper : FootballPlayer
	{


		/// <summary>
		/// Recall that inside a class definition, 
		/// you can use the keyword "this" to refer to this instance. 
		/// Similarly, the keyword "super" refers to the superclass, 
		/// which could be the immediate parent or its ancestor.
		/// </summary>
		public GoalKeeper() : base() //superclass constructor
		{
		}

		/// <summary>
		/// In the body of a constructor, 
		/// you can use super(args) 
		/// to invoke a constructor of its immediate superclass. 
		/// Note that super(args), if it is used, 
		/// must be the first statement in the subclass' constructor. 
		/// If it is not used in the constructor, 
		/// Java compiler automatically insert a super() statement 
		/// to invoke the no-arg constructor of its immediate superclass. 
		/// This follows the fact that the parent must be born 
		/// before the child can be born. 
		/// You need to properly construct the superclasses 
		/// before you can construct the subclass. 
		/// </summary>
		public GoalKeeper(string name, int number) : base(name, number) //demo with and without this line.
		{
		}

		public void CatchBall()
		{
			Console.WriteLine("GoalKeeper: catchBall()");
		}

		public override void Pass()
		{
			Console.WriteLine("GoalKeeper: pass() - a long long pass");
		}

		public void PracticePassing()
		{
			Console.WriteLine("GoalKeeper: start practice passing***");
			Pass();
			Pass();
			Console.WriteLine("GoalKeeper: end practice passing***");
		}

		public override void Shoot()
		{
			Console.WriteLine("GoalKeeper: I am bad at shooting. ");
		}


	}

}