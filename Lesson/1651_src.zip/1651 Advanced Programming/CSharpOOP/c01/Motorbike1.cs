﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpOOP.c01
{
    public class Motorbike1
    {
        //instance variable - the attributes
        public string brand;
        public int wheels;
        public double speed;
        public double speedIncrement;

        //constructor
        //A constructor in Java is a special method that is used to initialize objects. 
        //The constructor is called when an object of a class is created. 
        //It can be used to set initial values for object attributes

        //default constructor, automatically created if there is no constructor
        public Motorbike1()
        {
            this.brand = "Unknown";
            this.wheels = 2;
            this.speed = 0.0d;
            this.speedIncrement = 3.0d;
        }

        //parameterized constructor, manually created
        public Motorbike1(string brand, int wheels, double speedIncrement)
        {
            this.brand = brand;
            this.wheels = wheels;
            this.speedIncrement = speedIncrement;
            this.speed = 0.0d;
        }

        //methods - the actions
        public void Accelerate()
        {
            this.speed += this.speedIncrement;
        }

        public void Stop()
        {
            this.speed = 0;
        }
    }
}
