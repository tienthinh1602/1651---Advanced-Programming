﻿using FactoryMethodPattern.Pet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodPattern.End.FactoryMethod
{
    public class FishFactory : IPetFactory
    {
        public IPet CreatePet(string name, double weight, int birthYear)
        {
            var fish = new Fish(name, weight);
            fish.Environment = WaterType.FRESH;
            return fish;
        }
    }
}
