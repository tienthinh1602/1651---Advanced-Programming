﻿/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace CSharpOOP.c03.interface1
{
	/// 
	/// <summary>
	/// A Java interface is a 100% abstract superclass 
	/// which define a set of methods its subclasses must support. 
	/// An interface contains only public abstract methods 
	/// (methods with signature and no implementation) 
	/// and possibly constants (public static final variables). 
	/// You have to use the keyword "interface" to define an interface 
	/// (instead of keyword "class" for normal classes). 
	/// The keyword public and abstract are not needed for its abstract methods 
	/// as they are mandatory.
	/// </summary>
	public interface ICalculator
	{
		int SumDigits(int n);

	}


	//    int reverseNumber(int n);
}