﻿using Decorator.Model;
using Decorator.Model.ConcreteComponents;
using Decorator.Model.ConcreteDecorators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    class Program
    {
        static void Main(string[] args)
        {
            Pizza myPizza = new LargePizza();
            myPizza = new Cheese(myPizza);
            myPizza = new Ham(myPizza);
            myPizza = new Peppers(myPizza);
            //myPizza = new Ham(myPizza);

            Console.WriteLine(myPizza.GetDescription());
            Console.WriteLine("{0:C2}", myPizza.CalculateCost());

            Console.ReadKey();
        }
    }
}
