﻿using Bridge.Appointment;
using Bridge.Services;
using Bridge.ServiceWorker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge
{
    class Program
    {
        static void Main(string[] args)
        {
            var svc = new HairCut();
            svc.Duration = 2;

            var worker = new JuniordWorker();

            var sappt = new Scheduled(svc, worker);
            sappt.ArrivalTime = DateTime.Today 
                //+ new TimeSpan(15, 0, 0);
                + new TimeSpan(16, 0, 0);
            Console.WriteLine("Scheduled: Estimated Complete Time: {0}",
                sappt.EstimateCompleteTime().ToString("f"));




            var sworker = new SeniorWorker();
            var eappt = new Emergency(svc, sworker);
            eappt.ArrivalTime = DateTime.Today
                + new TimeSpan(17, 0, 0);
            Console.WriteLine("Emergency: Estimated Complete Time: {0}",
                eappt.EstimateCompleteTime().ToString("f"));

            Console.Read();
        }
    }
}
