﻿using FactoryMethodPattern.Pet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodPattern.End
{
    public class Customer
    {
        public string Contact { get; set; }
        public string Name { get; set; }
        public IPet MyPet { get; set; }

        public Customer(string contact, string name)
        {
            Contact = contact;
            Name = name;
        }
    }
}
