﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Plain Code
            //Console.Write("Enter first number: ");
            //string firstStr = Console.ReadLine();
            //int first = int.Parse(firstStr);

            //Console.Write("Enter second number: ");
            //string secondStr = Console.ReadLine();
            //int second = int.Parse(secondStr);

            //Console.WriteLine("Sum: " + (first + second));
            //Console.WriteLine("Program completed!");
            #endregion


            #region Try Catch Finally
            //try
            //{
            //    Console.Write("Enter first number: ");
            //    int first = int.Parse(Console.ReadLine());
            //    Console.Write("Enter second number: ");
            //    int second = int.Parse(Console.ReadLine());

            //    Console.WriteLine("Sum: " + (first + second));

            //    Console.WriteLine("Diff: " + (first - second));
            //    Console.WriteLine("Mult: " + (first * second));
            //    Console.WriteLine("Div: " + (first / second));

            //    Console.WriteLine("Hello World".Substring(20));

            //}
            //catch (FormatException)
            //{
            //    Console.WriteLine("Invalid Input");
            //}
            //catch (DivideByZeroException)
            //{
            //    Console.WriteLine("Cannot divide by 0");
            //}
            //catch (System.Exception e)
            //{
            //    Console.WriteLine("Something went wrong");
            //    Console.WriteLine(e.Message);
            //}
            //finally
            //{
            //    Console.WriteLine("Put your code to close database");
            //    Console.WriteLine("Put your code to close file reading");
            //    Console.WriteLine("Put your code to close file writing");
            //}

            #endregion

            #region Validation with TryCatch
            //Write a program to ask users to enter an age.
            //an age is from 0 to 100
            //if users enter a value outside the range,
            //print out Invalid Age and ask users to enter again
            //if users' input is not a number
            //print out "Your input is not a number" and ask users to enter again

            int x;
            do
            {
                try
                {
                    Console.Write("Please enter your age: ");
                    x = int.Parse(Console.ReadLine());
                    if (x < 0 || x > 100)
                    {
                        Console.WriteLine("Invalid Age");
                    }
                }
                catch (System.Exception)
                {
                    x = -1;
                    Console.WriteLine("Your input is not a number");
                }
            } while (x < 0 || x > 100);

            Console.WriteLine("Your age is {0}", x);
            #endregion


            #region StackTrace
            //CallMethodA();

            //try
            //{
            //    CallMethodA();
            //}
            //catch (System.Exception e)
            //{
            //    Console.WriteLine(e.StackTrace);
            //}
            #endregion






            Console.Read();
        }

        private static void CallMethodA()
        {
            CallMethodB();
        }

        private static void CallMethodB()
        {
            CallMethodC();
        }

        private static void CallMethodC()
        {
            //ScanFile("abc/xyz.txt");
            Add(1, 0);
        }

        private static int Add(int a, int b)
        {
            if (a == 0 || b == 0)
            {
                //actively raise an exception
                var e = new System.Exception("a or b equals to 0");
                throw e;
            }

            return a + b;
        }

        static void ScanFile(string path)
        {
            using (FileStream fs = File.Open(path, FileMode.Open))
            {
                Console.WriteLine(fs.Length);
            }


        }
    }
}
