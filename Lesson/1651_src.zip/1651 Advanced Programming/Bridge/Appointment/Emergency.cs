﻿using Bridge.Services;
using Bridge.ServiceWorker;
using System;

namespace Bridge.Appointment
{
    public class Emergency : Appointment
    {
        public Emergency(Service service, IServiceWorker sw)
            :base(service, sw)
        {}

        public override DateTime EstimateCompleteTime()
        {
            double duration = ServiceWorker.TimeTaken(this.Service);
            return ArrivalTime.AddHours(duration);
        }
    }
}
