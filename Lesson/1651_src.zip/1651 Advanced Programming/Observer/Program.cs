﻿using Observer.Customer;
using Observer.Notification;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    class Program
    {
        static void Main(string[] args)
        {
            var adNoti = new Advertising();

            for (int i = 0; i < 4; i++)
            {
                if (i % 2 == 0)
                {
                    var stdCust = new StandardCustomer
                    {
                        ID = i,
                        Name = "StdCust_" + i,
                        Contact = "+6593225" + i + i
                    };
                    stdCust.Subscribe(adNoti);
                } 
                else
                {
                    var goldCust = new GoldMemberCustomer
                    {
                        ID = i,
                        Name = "GoldCust_" + i,
                        Contact = "+6593225" + i + i
                    };
                    goldCust.Subscribe(adNoti);
                }
            }

            adNoti.DataSource.Add("Upcoming Year End SALE!!!");
            adNoti.Notify();

            adNoti.DataSource.Add("Happy New Year!!!");
            adNoti.Notify();

            Console.Read();
        }
    }
}
