﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodPattern.Pet
{
    public enum WaterType
    {
        FRESH, SALT
    }
    public class Fish : IPet
    {
        public string Name { get ; set ; }
        public double Weight { get ; set ; }
        public int BirthYear => 0;

        public WaterType Environment { get; set; }

        public Fish(string name, double weight)
        {
            Name = name;
            Weight = weight;
        }
 
        public int GetAge()
        {
            return 0;
        }
    }
}
