﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP
{
    public class Rectangle : Shape
    {
        public virtual double Width { get; set; } = 1.0;
        public virtual double Length { get; set; } = 1.0;

        public Rectangle()
        {

        }

        public Rectangle(double width, double length)
        {
            Width = width;
            Length = length;
        }

        public Rectangle(double width, double length, string color, bool filled)
            :this(width, length)
        {
            Color = color;
            Filled = filled;
        }

        public double GetArea()
        {
            return Length * Width;
        }

        public double GetPerimeter()
        {
            return 2 * (Length + Width);
        }

        public override string ToString()
        {
            return "Rectangle";
        }
    }
}
