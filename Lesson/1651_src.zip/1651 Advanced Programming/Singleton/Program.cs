﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton
{
    class Program
    {
        static void Main(string[] args)
        {
            var printer1 = Printer.GetInstance();

            printer1.PrintDocument(null);

            var printer2 = Printer.GetInstance();

            printer2.PrintDocument("Hello Singleton!");

            Console.Read();
        }
    }
}
