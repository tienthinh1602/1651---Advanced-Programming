﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP
{
    public class Circle : Shape
    {
        public double Radius { get; set; } = 1.0;
        public Circle()
        {

        }

        public Circle(double radius)
        {
            Radius = radius;
        }

        public Circle(double radius, string color, bool filled) : this(radius)
        {
            Color = color;
            Filled = filled;
        }

        public double GetArea()
        {
            return Math.Pow(Radius, 2) * Math.PI;
        }

        public double GetPerimeter()
        {
            return 2 * Math.PI * Radius;
        }
    }
}
