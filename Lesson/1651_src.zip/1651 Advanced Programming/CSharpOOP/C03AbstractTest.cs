﻿using CSharpOOP.c03.abstract1;
using System;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace CSharpOOP
{
	/// 
	/// <summary>
	/// @author Administrator
	/// </summary>
	public class TestAbstract
	{
		public static void Main(string[] args)
		{
			//initiate an array of FootballPlayer variables
			FootballPlayer[] players = new FootballPlayer[2];
            //players[0] = new FootballPlayer("John", 12); //cannot create intances of an abstract class
            players[0] = new GoalKeeper("John", 12); //create a GK obj
			players[1] = new Forward("Kevin", 9); //create a FW obj

			foreach (FootballPlayer p in players)
			{
				Console.WriteLine(p);
			}

			players[0].Practice();
			players[1].Practice();

            foreach (FootballPlayer p in players)
            {
                p.Shoot();
            }

            //players[2].CatchBall(); //why can't he catchBall()?
            GoalKeeper gk = (GoalKeeper)players[0]; // correct casting
            gk.CatchBall();

            //GoalKeeper anotherGK = (GoalKeeper)players[1]; // incorrect casting, runtime error
            //anotherGK.CatchBall();

			Console.Read();
        }
	}

}