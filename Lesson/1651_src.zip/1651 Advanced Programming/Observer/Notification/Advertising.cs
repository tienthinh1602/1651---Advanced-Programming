﻿using Observer.Customer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer.Notification
{
    public class Advertising : NotificationCenter
    {
        public override void Notify()
        {
            var dataId = DataSource.Count - 1;
            CustomerObservers.ForEach(cust => cust.Update(dataId));
        }
    }
}
