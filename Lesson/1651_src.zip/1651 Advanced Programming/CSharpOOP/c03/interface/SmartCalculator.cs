﻿using System;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace CSharpOOP.c03.interface1
{
	/// 
	/// <summary>
	/// @author Administrator
	/// </summary>
	public class SmartCalculator : ICalculator
	{

		public void DoNotCallMe()
		{
			Console.WriteLine("Don't call me!");
		}

		public int SumDigits(int n)
		{
			int sum = 0;
			while (n > 0)
			{
				sum += n % 10;
				n /= 10;
			}
			return sum;
		}


	}

	//    @Override
	//    public int reverseNumber(int n) {
	//        int nRev = 0;
	//        while (n > 0) {
	//            nRev = nRev * 10 + n % 10;
	//            n /= 10;
	//        }
	//        return nRev;
	//    }
}