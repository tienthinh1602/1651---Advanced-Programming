﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodPattern.Pet
{
    public class Dog : IPet
    {
        private int _birthYear;
        public string Name { get ; set ; }
        public double Weight { get ; set ; }
        public bool IsVaccinated { get; set; } = false;
        public int BirthYear 
        {
            get { return _birthYear; }
        }

        public Dog(string name, double weight, int birthYear)
        {
            Name = name;
            Weight = weight;
            _birthYear = birthYear;
        }

        public int GetAge()
        {
            return DateTime.Today.Year - BirthYear;
        }
    }
}
