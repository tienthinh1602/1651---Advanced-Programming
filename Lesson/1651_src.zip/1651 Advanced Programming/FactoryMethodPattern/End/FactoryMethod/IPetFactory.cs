﻿using FactoryMethodPattern.Pet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodPattern.End.FactoryMethod
{
    public interface IPetFactory
    {
        IPet CreatePet(string name, double weight, int birthYear);
    }
}
