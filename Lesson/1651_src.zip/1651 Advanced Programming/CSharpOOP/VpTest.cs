﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VP;

namespace CSharpOOP
{
    class VpTest
    {
        static void Main(string[] args)
        {
            //Square s = new Square(2);
            //Console.WriteLine(s.GetArea()); //4
            //Console.WriteLine(s.GetPerimeter()); //8

            //s.Side = 3;
            //Console.WriteLine(s.GetArea()); //9
            //Console.WriteLine(s.GetPerimeter()); //12

            //s.Length = 4;
            //Console.WriteLine(s.GetArea()); //16
            //Console.WriteLine(s.GetPerimeter()); //16

            //s.Width = 5;
            //Console.WriteLine(s.GetArea()); //25
            //Console.WriteLine(s.GetPerimeter()); //20

            IPet myCat = new Cat("abc");
            Console.WriteLine(myCat.Name);
            myCat.Play();

            myCat.Name = "xyz";
            Console.WriteLine(myCat.Name);
            myCat.Play();
            Console.Read();
        }
    }
}
