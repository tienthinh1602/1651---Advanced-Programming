﻿using Strategy.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy.End.ShippingStrategy
{
    public class AirShippingStrategy : IShippingStrategy
    {
        public double CalculateCost(Order order)
        {
            return order.GetWeight() * 5.15;
        }
    }
}
