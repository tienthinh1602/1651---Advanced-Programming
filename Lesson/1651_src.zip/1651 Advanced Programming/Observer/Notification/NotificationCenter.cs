﻿using Observer.Customer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer.Notification
{
    public abstract class NotificationCenter
    {
        protected List<ICustomer> CustomerObservers { get; set; }
        public List<string> DataSource { get; private set; }

        public NotificationCenter()
        {
            CustomerObservers = new List<ICustomer>();
            DataSource = new List<string>();
        }

        public abstract void Notify();
        public void Register(ICustomer cust)
        {
            if (!CustomerObservers.Any(c => c.ID == cust.ID))
            {
                CustomerObservers.Add(cust);
            }

        }
        public void Unregister(ICustomer cust)
        {
            CustomerObservers.RemoveAll(c => c.ID == cust.ID);
        }
    }
}
