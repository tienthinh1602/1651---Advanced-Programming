﻿using Strategy.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy.Begin
{
    public class ShippingCostService
    {
        public double CalculateShippingCost(Order order)
        {
            switch (order.ShipVia)
            {
                case ShippingMethod.AIR:
                    return CalculateForAir(order);

                case ShippingMethod.TRAIN:
                    return CalculateForTrain(order);

                case ShippingMethod.TRUCK:
                    return CalculateForTruck(order);
                    
                default:
                    return -1;
            }
        }

        double CalculateForAir(Order order)
        {
            return order.GetWeight() * 5.15;
        }

        double CalculateForTrain(Order order)
        {
            return order.GetWeight() * 2.7;
        }

        double CalculateForTruck(Order order)
        {
            return order.GetWeight() * 3.3;
        }
    }
}
